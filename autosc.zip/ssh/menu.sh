#!/bin/bash
clear
m="\033[0;1;36m"
y="\033[0;1;37m"
yy="\033[0;1;32m"
yl="\033[0;1;33m"
wh="\033[0m"
color1='\e[031;1m'
color2='\e[34;1m'
color3='\e[0m'
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[1;31m'
green='\e[1;32m'
blue='\e[1;34m'
PURPLE='\e[1;95m'
CYAN='\e[1;36m'
Lred='\e[1;91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
white='\e[1;37m'
NC='\e[0m'

echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "$y          Telegram : https://t.me/Waan_ID $wh"
echo -e "$y        Premium Auto Script By WaanStore $wh"
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "   \E[41;1;39m                ⇱ SSH & OpenVPN ⇲                \E[0m"
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━$NC"
echo -e "   [${green}01${NC}]${color1} •$white Create SSH & OpenVPN Account"
echo -e "   [${green}02${NC}]${color1} •$white Generate SSH & OpenVPN Trial Account"
echo -e "   [${green}03${NC}]${color1} •$white Extending SSH & OpenVPN Account Active Life"
echo -e "   [${green}04${NC}]${color1} •$white Check User Login SSH & OpenVPN"
echo -e "   [${green}05${NC}]${color1} •$white Daftar Member SSH & OpenVPN"
echo -e "   [${green}06${NC}]${color1} •$white Delete SSH & OpenVpn Account"
echo -e "   [${green}07${NC}]${color1} •$white Delete User Expired SSH & OpenVPN"
echo -e "   [${green}08${NC}]${color1} •$white Set up Autokill SSH"
echo -e "   [${green}09${NC}]${color1} •$white Displays Users Who Do Multi Login SSH"
echo -e "   [${green}10${NC}]${color1} •$white Restart All Service"
echo -e ""
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "   \E[41;1;39m                     ⇱ L2TP ⇲                    \E[0m"
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━$NC"
echo -e "   [${green}11${NC}]${color1} •$white Create Account L2TP"
echo -e "   [${green}12${NC}]${color1} •$white Delete Account L2TP"
echo -e "   [${green}13${NC}]${color1} •$white Extending Account L2TP Active Life"
echo -e ""
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "   \E[41;1;39m                  ⇱ PPTP ⇲                       \E[0m"
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━$NC"
echo -e "   [${green}14${NC}]${color1} •$white Create Account PPTP"
echo -e "   [${green}15${NC}]${color1} •$white Delete Account PPTP"
echo -e "   [${green}16${NC}]${color1} •$white Extending Account PPTP Active Life"
echo -e ""
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "   \E[41;1;39m                  ⇱ SSTP ⇲                       \E[0m"
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━$NC"
echo -e "   [${green}17${NC}]${color1} •$white Create Account SSTP"
echo -e "   [${green}18${NC}]${color1} •$white Delete Account SSTP"
echo -e "   [${green}19${NC}]${color1} •$white Extending Account SSTP Active Life"
echo -e "   [${green}20${NC}]${color1} •$white Check User Login SSTP"
echo -e ""
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "   \E[41;1;39m                  ⇱ WIREGUARD ⇲                  \E[0m"
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━$NC"
echo -e "   [${green}21${NC}]${color1} •$white Create Account Wireguard"
echo -e "   [${green}22${NC}]${color1} •$white Delete Account Wireguard"
echo -e "   [${green}23${NC}]${color1} •$white Extending Account Wireguard Active Life"
echo -e ""
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "   \E[41;1;39m                  ⇱ SHADOWSOCKS ⇲                \E[0m"
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━$NC"
echo -e "   [${green}24${NC}]${color1} •$white Create Account Shadowsocks"
echo -e "   [${green}25${NC}]${color1} •$white Delete Account Shadowsocks"
echo -e "   [${green}26${NC}]${color1} •$white Extending Account Shadowsocks Active Life"
echo -e "   [${green}27${NC}]${color1} •$white Check User Login Shadowsocks"
echo -e ""
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "   \E[41;1;39m                  ⇱ SHADOWSOCKSR ⇲               \E[0m"
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━$NC"
echo -e "   [${green}28${NC}]${color1} •$white Create Account SSR"
echo -e "   [${green}29${NC}]${color1} •$white Delete Account SSR"
echo -e "   [${green}30${NC}]${color1} •$white Extending Account SSR Active Life"
echo -e "   [${green}31${NC}]${color1} •$white Show Other SSR Menu"
echo -e ""
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "   \E[41;1;39m                  ⇱ XRAY / VMESS ⇲               \E[0m"
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━$NC"
echo -e "   [${green}32${NC}]${color1} •$white Create Account XRAYS Vmess Websocket"
echo -e "   [${green}33${NC}]${color1} •$white Delete Account XRAYS Vmess Websocket"
echo -e "   [${green}34${NC}]${color1} •$white Extending Account XRAYS Vmess Active Life"
echo -e "   [${green}35${NC}]${color1} •$white Check User Login XRAYS Vmess"
echo -e "   [${green}36${NC}]${color1} •$white Renew Certificate XRAYS Account"
echo -e ""
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "   \E[41;1;39m                  ⇱ XRAY / VLESS ⇲               \E[0m"
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━$NC"
echo -e "   [${green}37${NC}]${color1} •$white Create Account XRAYS Vless Websocket"
echo -e "   [${green}38${NC}]${color1} •$white Delete Account XRAYS Vless Websocket"
echo -e "   [${green}39${NC}]${color1} •$white Extending Account XRAYS Vless Active Life"
echo -e "   [${green}40${NC}]${color1} •$white Check User Login XRAYS Vless"
echo -e ""
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "   \E[41;1;39m                  ⇱ XRAY / TROJAN ⇲              \E[0m"
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━$NC"
echo -e "   [${green}41${NC}]${color1} •$white Create Account XRAYS Trojan"
echo -e "   [${green}42${NC}]${color1} •$white Delete Account XRAYS Trojan"
echo -e "   [${green}43${NC}]${color1} •$white Extending Account XRAYS Trojan Active Life"
echo -e "   [${green}44${NC}]${color1} •$white Check User Login XRAYS Trojan"
echo -e ""
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "   \E[41;1;39m                  ⇱ TROJAN GO ⇲                  \E[0m"
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━$NC"
echo -e "   [${green}45${NC}]${color1} •$white Create Account Trojan Go"
echo -e "   [${green}46${NC}]${color1} •$white Delete Account Trojan Go"
echo -e "   [${green}47${NC}]${color1} •$white Extending Account Trojan Go Active Life"
echo -e "   [${green}48${NC}]${color1} •$white Check User Login Trojan Go"
echo ""
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "   \E[41;1;39m                     ⇱ SYSTEM ⇲                  \E[0m"
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━$NC"
echo -e "   [${green}49${NC}]${color1} •$white Add Or Change Subdomain Host For VPS"
echo -e "   [${green}50${NC}]${color1} •$white Change Port Of Some Service"
echo -e "   [${green}51${NC}]${color1} •$white Autobackup Data VPS"
echo -e "   [${green}52${NC}]${color1} •$white Backup Data VPS"
echo -e "   [${green}53${NC}]${color1} •$white Restore Data VPS"
echo -e "   [${green}54${NC}]${color1} •$white Webmin Menu"
echo -e "   [${green}55${NC}]${color1} •$white Limit Bandwith Speed Server"
echo -e "   [${green}56${NC}]${color1} •$white Check Usage of VPS Ram"
echo -e "   [${green}57${NC}]${color1} •$white Reboot VPS"
echo -e "   [${green}58${NC}]${color1} •$white Speedtest VPS"
echo -e "   [${green}59${NC}]${color1} •$white Displaying System Information"
echo -e "   [${green}60${NC}]${color1} •$white Info Script Auto Install"
echo -e "   [${green}61${NC}]${color1} •$white Status Running Service"
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "   [${green}00${NC}]${color1} •$white BACK TO EXIT MENU \033[1;32m<\033[1;33m<\033[1;31m<\033[1;31m $NC"
echo -e "  $CYAN ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ $NC"
echo -e ""
    read -p "Select From Options [ 1 - 61 ] : " menu
echo -e ""
echo -e ""
case $menu in
1 | 01)
addssh
;;
2 | 02)
trialssh
;;
3 | 03)
renewssh
;;
4 | 04)
cekssh
;;
5 | 05)
member
;;
6 | 06)
delssh
;;
7 | 07)
delexp
;;
8 | 08)
autokill
;;
9 | 09)
ceklim
;;
10)
restart
;;
11)
addl2tp
;;
12)
dell2tp
;;
13)
renewl2tp
;;
14)
addpptp
;;
15)
delpptp
;;
16)
renewpptp
;;
17)
addsstp
;;
18)
delsstp
;;
19)
renewsstp
;;
20)
ceksstp
;;
21)
addwg
;;
22)
delwg
;;
23)
renewwg
;;
24)
addss
;;
25)
delss
;;
26)
renewss
;;
27)
cekss
;;
28)
addssr
;;
29)
delssr
;;
30)
renewssr
;;
31)
ssr
;;
32)
addv2ray
;;
33)
delv2ray
;;
34)
renewv2ray
;;
35)
cekv2ray
;;
36)
certv2ray
;;
37)
addvless
;;
38)
delvless
;;
39)
renewvless
;;
40)
cekvless
;;
41)
addtrojan
;;
42)
deltrojan
;;
43)
renewtrojan
;;
44)
cektrojan
;;
45)
addtrgo
;;
46)
deltrgo
;;
47)
renewtrgo
;;
48)
cektrgo
;;
49)
addhost
;;
50)
changeport
;;
51)
autobackup
;;
52)
backup
;;
53)
restore
;;
54)
wbmn
;;
55)
limitspeed
;;
56)
ram
;;
57)
reboot
;;
58)
speedtest
;;
59)
info
;;
60)
about
;;
61)
running
;;
0 | 00)
exit
;;
*)
menu
;;
esac
